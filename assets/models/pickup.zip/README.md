# Original low-poly military pickup

This pickup is authored from scratch by `scripts/blender/build_player.py`.
No mesh data is imported from the legacy JSON or the runtime truck factory.
The military utility design uses a wider body, matte olive paint, smaller
windows, brush guard and protected lamps, tow eyes, a cab protection rack,
roof access hatch and a mounted jerrycan. The cargo bed remains open. This is
an original stylized design, not a dimensionally accurate branded replica.

- `player.blend`: editable body and four wheel assemblies, with packed palette.
- `player.obj`, `player.mtl`, `palette.png`: portable geometry and colors. Keep
  all three files together.
- `preview.png`, `preview_rear.png`: front and rear views of the pickup.
- `stats.json`: measured geometry, material and mesh counts.

Blender uses Z-up, with the front of the pickup facing -Y. The four wheels share
one mesh datablock and have separate pivot parents. The body uses another mesh.
All five mesh objects share one material and a 32x32 color palette. UVs map faces
to palette swatches; they are not an unwrap for painting unique surface textures.

OBJ is Y-up, forward -Z. OBJ preserves separate wheel objects but cannot store
Blender parenting or shared mesh datablocks. Presentation cameras, lights and
ground are excluded from OBJ. The model is not yet connected to the game runtime.

Rebuild from the project root:

```sh
/Applications/Blender.app/Contents/MacOS/Blender --background --factory-startup --python-exit-code 1 --python scripts/blender/build_player.py
```

Rebuilding overwrites generated files; save hand-edited variants under a new name.
